public class Main{
	public static void main(String[] args) {
		System.out.println("Hello World");
		System.out.println("D2 developer");
		System.out.println("Hello World");
		System.out.println("By D1 developer");
	}
}
